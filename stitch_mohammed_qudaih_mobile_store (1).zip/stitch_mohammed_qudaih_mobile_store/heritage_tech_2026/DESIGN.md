---
name: Heritage Tech 2026
colors:
  surface: '#131412'
  surface-dim: '#131412'
  surface-bright: '#393937'
  surface-container-lowest: '#0e0e0d'
  surface-container-low: '#1b1c1a'
  surface-container: '#1f201e'
  surface-container-high: '#2a2a28'
  surface-container-highest: '#353533'
  on-surface: '#e4e2de'
  on-surface-variant: '#c5c8bd'
  inverse-surface: '#e4e2de'
  inverse-on-surface: '#30312e'
  outline: '#8f9289'
  outline-variant: '#454840'
  surface-tint: '#bdcbae'
  primary: '#bdcbae'
  on-primary: '#28341f'
  primary-container: '#2d3924'
  on-primary-container: '#95a387'
  inverse-primary: '#55624a'
  secondary: '#ffb3b1'
  on-secondary: '#680012'
  secondary-container: '#9f0221'
  on-secondary-container: '#ffa8a6'
  tertiary: '#c6c6c7'
  on-tertiary: '#2f3131'
  tertiary-container: '#343636'
  on-tertiary-container: '#9e9f9f'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#d9e7c9'
  primary-fixed-dim: '#bdcbae'
  on-primary-fixed: '#131f0c'
  on-primary-fixed-variant: '#3e4a34'
  secondary-fixed: '#ffdad8'
  secondary-fixed-dim: '#ffb3b1'
  on-secondary-fixed: '#410007'
  on-secondary-fixed-variant: '#92001d'
  tertiary-fixed: '#e2e2e2'
  tertiary-fixed-dim: '#c6c6c7'
  on-tertiary-fixed: '#1a1c1c'
  on-tertiary-fixed-variant: '#454747'
  background: '#131412'
  on-background: '#e4e2de'
  surface-variant: '#353533'
typography:
  display-xl:
    fontFamily: Space Grotesk
    fontSize: 40px
    fontWeight: '700'
    lineHeight: '1.1'
    letterSpacing: -0.04em
  headline-lg:
    fontFamily: Space Grotesk
    fontSize: 24px
    fontWeight: '600'
    lineHeight: '1.2'
  body-md:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: '1.6'
  label-caps:
    fontFamily: Space Grotesk
    fontSize: 12px
    fontWeight: '500'
    lineHeight: '1'
    letterSpacing: 0.1em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  unit: 4px
  xs: 4px
  sm: 8px
  md: 16px
  lg: 24px
  xl: 40px
  container-margin: 20px
  gutter: 12px
---

## Brand & Style

The brand personality is a fusion of deep-rooted Palestinian heritage and cutting-edge 2026 mobile technology. It balances the warmth of cultural identity with the cold, precise efficiency of a high-end digital boutique. The target audience is tech-savvy consumers who value premium craftsmanship and cultural storytelling.

The design style is **Glassmorphism mixed with Minimalism**. It utilizes high-density information displays, translucent "smart glass" surfaces, and vibrant accent blurs to create a sense of depth and future-ready sophistication. The interface should feel like a holographic projection—airy yet grounded by strong structural geometry.

## Colors

The palette is a sophisticated "Noir-Heritage" scheme. The background is a deep, near-black olive green (`#2D3924`) that provides a more organic feel than pure charcoal. 

- **Primary:** Deep Olive Green serves as the foundation for surfaces and branding.
- **Secondary:** A rich, deep crimson inspired by traditional embroidery (Tatreez), used for high-impact CTAs and critical alerts.
- **Neutral:** A range of stark whites and tech-blacks to maintain a professional, high-tech aesthetic.
- **Functional:** Subtle use of gold-tinted whites for "Premium" product tiers.

## Typography

This design system utilizes **Space Grotesk** for headlines and interactive elements to provide a technical, futuristic edge that remains highly legible in both English and Arabic script. For long-form content and product descriptions, **Inter** is used for its exceptional clarity and neutral tone.

Headlines should utilize "Optical Kerning" to appear tighter and more authoritative. Arabic type should be weighted slightly heavier than its English counterpart to maintain visual optical balance across the bilingual interface.

## Layout & Spacing

The layout follows a **fluid grid** model optimized for the 2026 mobile viewport. We use a 6-column grid for mobile with tight gutters to maximize screen real estate for product imagery. 

Spacing follows a strict 4px baseline grid to ensure mathematical harmony. Large "breathable" margins are reserved for the top of the fold (hero sections), while product grids transition into a more dense, utilitarian layout to facilitate rapid browsing.

## Elevation & Depth

Depth is established through **Backdrop Blurs** and **Ambient Glows** rather than traditional drop shadows. 

- **Level 1 (Base):** Deep Olive background.
- **Level 2 (Cards):** Semi-transparent (80% opacity) surfaces with a 1px inner border (white at 10% opacity) to simulate glass edges.
- **Level 3 (Modals/Nav):** High-saturation backdrop blur (20px radius) with a subtle external glow in a muted red or olive to indicate focus.
- **Product Depth:** High-end products use a "rim light" effect—a thin, vibrant gradient border that makes the card appear to emit its own light.

## Shapes

The shape language is **"Geometric-Soft"**. We use a base radius of 8px (`rounded-md`) for standard UI components like inputs and small buttons. Larger components like product cards and navigation docks use a 16px to 24px radius (`rounded-lg` to `rounded-xl`) to create a friendlier, ergonomic handheld feel. High-priority action buttons may use a pill-shape to distinguish them from structural elements.

## Components

### Futuristic Navigation Bar
A floating "dock" located at the bottom of the screen. It features a frosted glass background with active icons highlighted by a "pulse" animation in deep red.

### High-End Product Cards
Cards feature edge-to-edge photography with a subtle gradient overlay at the bottom for legibility. Price tags are displayed in a "mono" styled font (Space Grotesk) to emphasize technical specs.

### Call-to-Action Buttons
Buttons use a dual-tone gradient (Deep Red to Vibrant Red). On hover or tap, they emit a soft red shadow-glow to simulate a powered-on state.

### Tatreez Accent Chips
Status indicators (e.g., "In Stock", "New") feature a micro-pattern inspired by Palestinian embroidery, used as a subtle texture behind the text label.

### Input Fields
Minimalist under-line inputs that animate into a full-boxed glass state when focused, using the primary olive green as the active accent.